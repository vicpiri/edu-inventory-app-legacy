<?php

/* 
 * info.php
 * 
 * Este archivo contiente la información descriptiva sobre el módulo
 * 
 */

$nombre_modulo = 'Interfaz de Ítaca';

$descripcion_modulo = 'Este módulo proporciona una interfaz para poder importar '
        . 'información provinente de la aplicación Ítaca.';

$version_modulo = '0.2';

$dependencias_modulo = [];

