<div class="panel panel-primary">
    <div class="panel-heading">Importación de datos</div>
    <div class="panel-body">
        </br>¿Necesita importar información de una versión anterior? </br></br>

    </div>
    <div class="panel-footer text-right">
        <a class="btn btn-success" href="index.php?stage=dbimport">Sí</a>
        <a class="btn btn-success" href="index.php?stage=superuserdata">No</a>
    </div>
</div>

