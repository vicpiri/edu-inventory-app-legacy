// javaGeneral.js: Aqu� residen funciones de prop�sito genereal como establecer el foco en un elemento de un formulario.
function setFocus(){
	document.getElementById("focalizado").focus();
	//alert("foco");
}

function setFocusID(IDelemento){
	document.getElementById(IDelemento).focus();
}
