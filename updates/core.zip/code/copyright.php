<?php

$copyright = "&copy; Víctor Pineda Ribes 2016. Todos los derechos reservados.";

