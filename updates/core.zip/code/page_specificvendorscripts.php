<!-- Specific Page Vendor -->
<div id="specificvendorscripts">
		<script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
		<script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
		<!-- <script src="assets/vendor/jquery-appear/jquery.appear.js"></script> -->
		<!-- <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script> -->
		<!-- <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script> -->
		<!-- <script src="assets/vendor/flot/jquery.flot.js"></script> --> 
		<!-- <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script> --> 
		<!-- <script src="assets/vendor/flot/jquery.flot.pie.js"></script> --> 
		<!-- <script src="assets/vendor/flot/jquery.flot.categories.js"></script> --> 
		<!-- <script src="assets/vendor/flot/jquery.flot.resize.js"></script> --> 
		<!-- <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script> --> 
		<!-- <script src="assets/vendor/raphael/raphael.js"></script> --> 
		<!-- <script src="assets/vendor/morris/morris.js"></script> -->
		<!-- <script src="assets/vendor/gauge/gauge.js"></script> -->
		<!-- <script src="assets/vendor/snap-svg/snap.svg.js"></script> -->
		<!-- <script src="assets/vendor/liquid-meter/liquid.meter.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/jquery.vmap.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script> -->
		<!-- <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script> -->
                <!-- <script src="assets/vendor/jquery-validation/jquery.validate.js"></script> -->
		<!-- <script src="assets/vendor/bootstrap-wizard/jquery.bootstrap.wizard.js"></script> -->
		<!-- <script src="assets/vendor/pnotify/pnotify.custom.js"></script> -->
                <!-- <script src="assets/vendor/select2/select2.js"></script> -->
		<script src="assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
		<script src="assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
		<script src="assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
                <script src="assets/javascripts/theme.custom.js"></script>
                <script src="assets/vendor/pnotify/pnotify.custom.js"></script>
                <script src="java/modals.js"></script>
                <script src="assets/vendor/bootstrap-wizard/jquery.bootstrap.wizard.js"></script>
                <script src="assets/vendor/jquery-validation/jquery.validate.js"></script>
                <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
                
</script>
</div>
                

