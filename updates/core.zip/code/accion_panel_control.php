
<!-- start: page -->
        
<div class="row" id="cpwidgets">

</div>
<div class="row" id="cppanels">
<?php
    include 'accion_panel_control_TMPmiPerfil.php';
?>
</div>
<!-- end: page -->