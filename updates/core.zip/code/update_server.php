<?php
require_once 'config.php';
$update_server = 'http://apps.moon-brain.com/inventario_support';
//$update_server = $baseURLClient . '_remotecode';

//Comentar esta última línea para la versión de producción.