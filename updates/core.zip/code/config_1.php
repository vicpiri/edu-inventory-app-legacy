<?php
//Configuración de la base de datos
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "inventario";
 
// Textos por defecto de la interfaz de la aplicación 
$nombreAplicacion = "Gestor de material y usuarios"; 
$nombreSeccion = ""; 
//Personalización de la aplicación
$title = "Gestor de inventario";
$logotipo = "assets/images/logollll.png";
//URL principal
$baseURL = __DIR__ . "/../";
$baseURLClient = "http://localhost/inventario/";
// Identificación de la instalación
$client = "CL588dd8f00beb9";
