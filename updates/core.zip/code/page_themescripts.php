<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>

                <!-- Examples -->
		<script src="assets/javascripts/tables/examples.datatables.default.js"></script>
		<script src="assets/javascripts/tables/examples.datatables.row.with.details.js"></script>
		<script src="assets/javascripts/tables/examples.datatables.tabletools.js"></script>
                
                <!-- Examples -->
		<!--<script src="assets/javascripts/pages/examples.lockscreen.js"></script>
		<script src="assets/javascripts/pages/examples.session.timeout.js"></script>
                <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>-->
