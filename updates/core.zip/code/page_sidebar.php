<!-- start: sidebar -->
                <aside id="sidebar-left" class="sidebar-left">

                        <div class="sidebar-header">
                                <div class="sidebar-title">
                                        Menú
                                </div>
                                <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
                                        <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                                </div>
                        </div>

                        <div class="nano">
                                <div class="nano-content">
                                        <?php require 'code/page_mainmenu.php'; ?>

                                        <hr class="separator" />
                                </div>

                        </div>

                </aside>
                <!-- end: sidebar -->

