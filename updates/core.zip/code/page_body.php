<section class="body">
    <?php require 'code/page_header.php';?>
    <?php require 'code/page_sidebar.php';?>

        <div class="inner-wrapper">
            <?php require 'code/page_main.php';?>
        </div>
</section>

