
<br/>
<div id="zonaForm">
<div class="alert alert-warning col-md-6 col-md-offset-3">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <strong>¡Atención!</strong> <br/> Al pulsar en el botón  <strong>'Finalizar'</strong> las imágenes que han dado un
        informe positivo en el análisis anterior se incorporarán a la base de datos y sustituirán a las imágenes antiguas
        que ya existan.
</div>
</div>

