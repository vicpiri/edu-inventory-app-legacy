<?php

/* 
 * Archivo para pruebas
 */


echo '<div>hola</div>';
