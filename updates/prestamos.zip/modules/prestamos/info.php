<?php

/* 
 * info.php
 * 
 * Este archivo contiente la información descriptiva sobre el módulo
 * 
 */

$nombre_modulo = 'Préstamos';

$descripcion_modulo = 'Este módulo instala las acciones para el control de préstamos de artículos.';

$version_modulo = '0.22';

$dependencias_modulo = [];

